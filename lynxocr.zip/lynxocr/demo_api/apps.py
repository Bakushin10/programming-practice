from django.apps import AppConfig


class DemoApiConfig(AppConfig):
    name = 'demo_api'
