from django.apps import AppConfig


class LynxApiAuthenticationConfig(AppConfig):
    name = 'lynx_api_authentication'
