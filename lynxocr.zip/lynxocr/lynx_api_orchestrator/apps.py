from django.apps import AppConfig


class LynxApiOrchestratorConfig(AppConfig):
    name = 'lynx_api_orchestrator'
