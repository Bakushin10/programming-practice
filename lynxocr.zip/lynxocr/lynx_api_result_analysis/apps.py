from django.apps import AppConfig


class LynxApiResultAnalysisConfig(AppConfig):
    name = 'lynx_api_result_analysis'
