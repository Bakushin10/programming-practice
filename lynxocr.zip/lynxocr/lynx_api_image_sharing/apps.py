from django.apps import AppConfig


class LynxApiImageSharingConfig(AppConfig):
    name = 'lynx_api_image_sharing'
