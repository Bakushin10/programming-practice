from django.apps import AppConfig


class LynxApiPerspectiveCorrectionConfig(AppConfig):
    name = 'lynx_api_perspective_correction'
