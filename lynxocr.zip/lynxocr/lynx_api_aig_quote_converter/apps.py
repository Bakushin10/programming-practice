from django.apps import AppConfig


class LynxApiAigQuoteConverterConfig(AppConfig):
    name = 'lynx_api_aig_quote_converter'
