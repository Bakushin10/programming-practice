from django.apps import AppConfig


class LynxApiOcrInvokingConfig(AppConfig):
    name = 'lynx_api_ocr_invoking'
