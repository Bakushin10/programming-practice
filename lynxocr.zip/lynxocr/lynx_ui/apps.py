from django.apps import AppConfig


class LynxUiConfig(AppConfig):
    name = 'lynx_ui'
