from django.contrib import admin
from .models import OrchestratorInputModel, OCRInputModel

# Register your models here.
admin.site.register(OrchestratorInputModel)
#admin.site.register(OCRInputModel)