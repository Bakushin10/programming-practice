from django.apps import AppConfig


class LynxApiQrcodeConfig(AppConfig):
    name = 'lynx_api_qrcode'
