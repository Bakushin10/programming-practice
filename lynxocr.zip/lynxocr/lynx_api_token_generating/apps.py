from django.apps import AppConfig


class LynxApiTokenGeneratingConfig(AppConfig):
    name = 'lynx_api_token_generating'
